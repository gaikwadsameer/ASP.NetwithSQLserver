﻿CREATE TABLE [dbo].[tbl_user]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [fname] VARCHAR(50) NULL, 
    [lname] VARCHAR(50) NULL, 
    [contact] INT NULL, 
    [email] VARCHAR(50) NULL
)
