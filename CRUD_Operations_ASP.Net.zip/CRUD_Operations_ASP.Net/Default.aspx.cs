﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btncreate_Click(object sender, EventArgs e)
    {
        string con = "Data Source=.;Initial Catalog=sameer;Integrated Security=True";  
        SqlConnection db = new SqlConnection(con);  
        db.Open();
        string insert = "insert into tbl_user (fname,lname,contact,email) values ('" + txtFname.Text + "','" + txtLname.Text + "','" + txtContact.Text + "','" + txtEmail.Text + "')";  
        SqlCommand cmd = new SqlCommand(insert,db);  
        int m = cmd.ExecuteNonQuery();  
        if(m != 0)  
        {  
           Response.Write("<script>alert('Data Inserted !!')</script>");  
        }  
        else  
        {  
           Response.Write("<script>alert('Data Inserted !!')</script>");  
        }  
        db.Close(); 
    }
}